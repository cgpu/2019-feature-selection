
<!-- README.md is generated from README.Rmd. Please edit that file -->
This is an unofficial development version of the `hsdar` R package by Lukas Lehnert. See `NEWS.md` for the changelog.

Based on CRAN mirror fork (version 0.5.1).
