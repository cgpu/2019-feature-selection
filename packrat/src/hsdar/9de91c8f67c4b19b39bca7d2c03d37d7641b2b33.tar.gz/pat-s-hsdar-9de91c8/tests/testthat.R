library(testthat)
library(hsdar)

test_check("hsdar")
