
#ifndef C2LABLAS_H
#define C2LABLAS_H

#include <R.h>
#include <Rinternals.h>

extern void F77_NAME(c2dgemv)(int *M, int *N, double *AM, double *X, double *Y);

#endif
